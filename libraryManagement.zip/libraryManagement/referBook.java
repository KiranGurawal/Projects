package library;
import java.util.Scanner;

class referBook {
	
		private String name;
	
	 public String getName(){
           return name;
       }
       public void setName(String name){
           this.name = name;
       }
	
		void issued(){
		System.out.println("This book can be issued(referBook-rBook)");
		
		}
		
		
	   void readBook(){
		System.out.println("This book can be read in libray (Refer Book class)");
		}


}