package libraryManagement;
import java.util.Scanner;
import java.sql.*;
class LibraryClass{
	
	
	static book b [] = new book[50];
	static journal j1[] = new journal[50];
	static referBook r[] = new referBook[50];
	static int i=0;
	static int j=0;
	static int k=0;
	

	public static void main(String args[]) throws SQLException {

		String url ="jdbc:mysql://localhost:3306/yash";
		String user = "root";
        String pass = "root";

		Connection conn = DriverManager.getConnection(url,user,pass);


		Scanner s = new Scanner(System.in);
		int c;
		int c1 =1;
		while(true){
			System.out.println("***************************************************");
			System.out.println("1.Add books 2.Search book  3.List book  4.Exit");
			System.out.println("***************************************************");
			c=s.nextInt();
			switch(c){
				case 1:
					addBook(s,conn);
				break;
				case 2:
				searchBook(s,conn);
				break;
				case 3:
				System.out.println("book name and type");
				listOfBook(conn);
				break;
				case 4:
					System.exit(0);
			}
			
		}
		
	
	
	}
	
	
	
	static void addBook(Scanner s, Connection c){
		int a;
		System.out.println("Book Type:");
		System.out.println("1.Book 2.journal 3.Reference Book");
		a = s.nextInt();
		System.out.println("Enter name: ");
		String name = s.next();
		switch(a){
			case 1:
			b[i] = new book();
			b[i].setName(name);

			try{
				String s2 = "SELECT * FROM book";
				Statement statement = c.createStatement();
				ResultSet rs = statement.executeQuery(s2);
				while(rs.next()){
					String bname = rs.getString(2);
//					System.out.println(bname.equals(b[i].getName()));
					if(bname.equals(b[i].getName())){
						System.out.println("The Book Your Trying to add is alredy there");
						System.exit(0);
					}
				}

			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}

				try {
				String s1 = "INSERT INTO book (name) VALUES (?)";
				PreparedStatement stmt = c.prepareStatement(s1);
				stmt.setString(1,b[i].getName());
				int row = stmt.executeUpdate();

			}catch (Exception e){
				System.out.println(e);
			}
			i++;
			break;
			case 2:
			j1[j] = new journal();
			j1[j].setName(name);

				try{
					String s2 = "SELECT * FROM journal";
					Statement statement = c.createStatement();
					ResultSet rs = statement.executeQuery(s2);
					while(rs.next()){
						String bname = rs.getString(2);
//						System.out.println(bname.equals(j1[j].getName()));
						if(bname.equals(j1[j].getName())){
							System.out.println("The journal Your Trying to add is alredy there");
							System.exit(0);
						}
					}

				} catch (SQLException throwables) {
					throwables.printStackTrace();
				}


				try {
					String s1 = "INSERT INTO journal (name) VALUES (?)";
					PreparedStatement stmt = c.prepareStatement(s1);
					stmt.setString(1,j1[j].getName());
					int row = stmt.executeUpdate();

				}catch (Exception e){
					e.printStackTrace();
				}

			j++;
			break;
			case 3:
			r[k] = new referBook();
			r[k].setName(name);
				try {
					String s1 = "INSERT INTO referBook (name) VALUES (?)";
					PreparedStatement stmt = c.prepareStatement(s1);
					stmt.setString(1,r[k].getName());
					int row = stmt.executeUpdate();

				}catch (Exception e){
					System.out.println(e);
				}
			k++;	
			break;
			default:
			System.out.println("Invalid input");
			break;
		}
	}
	
	
	static void searchBook(Scanner s , Connection c){
		int ch;
		String bname = null;
		System.out.println("book type:");
	    System.out.println("1.Book 2.journal 3.Reference Book");
		ch = s.nextInt();
		System.out.println("Enter book name:");
		bname = s.next();
		 switch(ch){
			 case 1:
				 try{
					 System.out.println(bname);
					 String s2 = "SELECT * FROM book";
					 Statement statement = c.createStatement();
					 ResultSet rs = statement.executeQuery(s2);
					 System.out.println("exe 165");
					 while(rs.next()){
						 String tempData = rs.getString(2);
						 int bid = rs.getInt(1);
//						 System.out.println(b[i].getName());
						 if(bname.equals(tempData)){
							 System.out.println(" Founded ");
							 System.out.println(" Id "+bid+" "+" Name "+bname);
							 System.exit(0);
						 }
					 }

				 } catch (SQLException throwables) {
					 throwables.printStackTrace();
				 }
				break;

				 
			case 2:
				try{
					String s2 = "SELECT * FROM journal";
					Statement statement = c.createStatement();
					ResultSet rs = statement.executeQuery(s2);
					while(rs.next()){
						bname = rs.getString(2);
						int bid = rs.getInt(1);
						if(bname.equals(b[i].getName())){
							System.out.println(" Founded ");
							System.out.println(" Id "+bid+" "+" Name "+bname);
							System.exit(0);
						}
					}

				} catch (SQLException throwables) {
					throwables.printStackTrace();
				}
				break;
				
			case 3:
				try{
					String s2 = "SELECT * FROM referBook";
					Statement statement = c.createStatement();
					ResultSet rs = statement.executeQuery(s2);
					while(rs.next()){
						bname = rs.getString(2);
						int bid = rs.getInt(1);
						if(bname.equals(b[i].getName())){
							System.out.println(" Founded ");
							System.out.println(" Id "+bid+" "+" Name "+bname);
							System.exit(0);
						}
					}

				} catch (SQLException throwables) {
					throwables.printStackTrace();
				}
				break;
					
		
			default:
				System.out.println("Invalid input");
				break;
					
		
				 
		}
	}
		 
		static void listOfBook(Connection c){
			try{
				String s2 = "SELECT * FROM book";
				Statement statement = c.createStatement();
				ResultSet rs = statement.executeQuery(s2);
				System.out.println("***********List Of Books *********");
				System.out.println("ID \t\t\t\t Book Name");
				while(rs.next()){
					String bname = rs.getString(2);
					int id = rs.getInt(1);
					System.out.println(id+" \t\t\t\t "+bname);
				}

				System.out.println("****************************");

			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}

			try{
				String s2 = "SELECT * FROM journal";
				Statement statement = c.createStatement();
				ResultSet rs = statement.executeQuery(s2);
				System.out.println("***********List Of Journal *********");
				System.out.println("ID \t\t\t\t Journal Name");
				while(rs.next()){
					String bname = rs.getString(2);
					int id = rs.getInt(1);
					System.out.println(id+" \t\t\t\t "+bname);
				}

				System.out.println("****************************");

			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}


			try{
				String s2 = "SELECT * FROM referBook";
				Statement statement = c.createStatement();
				ResultSet rs = statement.executeQuery(s2);
				System.out.println("***********List Of Refer Book *********");
				System.out.println("ID \t\t\t\t Refer Book Name");
				while(rs.next()){
					String bname = rs.getString(2);
					int id = rs.getInt(1);
					System.out.println(id+" \t\t\t\t "+bname);
				}

				System.out.println("****************************\n\n\n\n DONE\n");

			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}

//					for(int a=0;a<i;a++){
//						System.out.println(b[a].getName() + "        book");
//					}
//			         for(int a=0;a<j;a++){
//						System.out.println(j1[a].getName() + "        journal");
//					}
//			        for(int a=0;a<k;a++){
//						System.out.println(r[a].getName() + "        referBook");
//					}
			 
	}

	
		 
}
