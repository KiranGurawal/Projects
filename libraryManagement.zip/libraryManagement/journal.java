package library;
class journal{
	private String name;
	
	public String getName(){
           return name;
    }
    
	public void setName(String name){
        
       this.name = name;
    }
	
	private void issued(){
		System.out.println("This book can be issued (Journal)");
	}
	private void readBook(){
		System.out.println("This book can be read in libray (Journal)");
	}
}