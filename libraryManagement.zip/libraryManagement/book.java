package library;

interface bookProperties{
	public void readBook();
	
	public void issued();
}


class book implements bookProperties{
	private String name;
	
	 public String getName(){
           return name;
       }
       public void setName(String name){
          this.name = name;
       }
	   
     public void readBook(){
           System.out.println("This book can be read in libray");
       }
       public void issued(){
           System.out.println("This book cannot be issued");
       }
      

    }